({
	doSubmit : function(Comp) {
        console.log("--- doSubmit invoked -----");
        var mname = Comp.find("myName");
        var mybutt = Comp.find("buttonId");
        mybutt.set("v.label","power of LocalIds");
        mname.set("v.label","magic happened");
	}
})