({
	handleInit : function(component, event, helper) {
		console.log("init is the FIRST event, but, before RENDER");
	}
})