({
	myAction : function(component, event, helper) {
		alert("Great Job..!\n\nYou have shared this tip with your contacts.");
	}
})