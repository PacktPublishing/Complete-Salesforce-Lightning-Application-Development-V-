({
	doInit : function(htComp, htEvent, htHelper) {
        console.log("doInit()");
		htHelper.doInitHelper(htComp);
	},
    
    searchHealthTips : function(htComp, htEvent, htHelper)
    {
        htHelper.searchHealthTipsHelper(htComp,htEvent);
    },
    
})