({
    doInitHelper : function(htComp)
    {
        console.log("doInitHelper from HealthTipListHelper...");
        htComp.find("opText").set("v.value", "ALL HEALTH-TIPS");
        var htAction = htComp.get("c.returnAllHealthTips");
        htAction.setCallback(this,
                             function(htResp)
                              {
                                  htComp.set("v.healthTips", htResp.getReturnValue());
                                  console.log("server side ok");
                              });
        $A.enqueueAction(htAction);
        
    },
    
	searchHealthTipsHelper : function(htComp, htEvent) {
        var selCategoryFromSearchBarComp = htEvent.getParam("selCategory");
        console.log("the Category from SB ==> "+selCategoryFromSearchBarComp);
        
        var selCatValue = htComp.find("opText").set("v.value", "HEALTH-TIPS on "+selCategoryFromSearchBarComp);
           
        var htAction = htComp.get("c.returnHealthTipsByCategory");
        htAction.setParam("Category", selCategoryFromSearchBarComp);
        htAction.setCallback(this,
                             function(htResp)
                             {
                                 htComp.set("v.healthTips", htResp.getReturnValue());
                                 console.log("server side ok for HealthTips");
                             });
        $A.enqueueAction(htAction);
        }
})