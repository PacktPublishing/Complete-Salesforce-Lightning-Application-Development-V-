({
    doInitHelper : function(semComp)
    {
        semComp.find("opText").set("v.value", "ALL SEMINARS");
        var semAction = semComp.get("c.returnAllSeminars");
        semAction.setCallback(this,
                             function(semResp)
                              {
                                  semComp.set("v.seminars", semResp.getReturnValue());
                                  console.log("server side ok");
                              });
        $A.enqueueAction(semAction);
    },
    
	searchSeminarsHelper : function(semComp, semEvent) {
        console.log(".... appEvent Fired ......");
        var selCategoryFromSearchBarComp = semEvent.getParam("selCategory");
        console.log("the Category from SB ==> "+selCategoryFromSearchBarComp);
        
        var selCatValue = semComp.find("opText").set("v.value", "Seminars on "+selCategoryFromSearchBarComp);
        
        var semAction = semComp.get("c.returnSeminarsByCategory");
        semAction.setParam("Category", selCategoryFromSearchBarComp);
        semAction.setCallback(this,
                              function(semResp)
                              {
                                  semComp.set("v.seminars", semResp.getReturnValue());
                                  console.log("server side ok");
                              });
        $A.enqueueAction(semAction);
        
       
	}
})