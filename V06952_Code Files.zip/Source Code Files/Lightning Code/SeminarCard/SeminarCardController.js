({
	doEnroll : function(seminarComp, seminarEvent, seminarHelper) {
		alert("Congrats..! \n\nYou have been successfully erolled for this Seminar");
	}
})